namespace ATMProject
{
    /// <summary>
    /// A checking account with optional overdraft protection.
    ///
    /// <para>
    /// Demonstrates <b>polymorphism</b> by overriding <see cref="Account.Withdraw"/>.
    /// When the checking balance alone cannot cover the requested amount, the
    /// deficit is automatically drawn from a linked <see cref="SavingsAccount"/>
    /// — if one exists and holds sufficient funds.
    /// </para>
    /// </summary>
    public class CheckingAccount : Account
    {
        // ----------------------------------------------------------------
        // Properties
        // ----------------------------------------------------------------

        /// <inheritdoc/>
        public override string AccountType => "Checking";

        /// <summary>
        /// Optional reference to the customer's savings account used for
        /// overdraft coverage. May be <c>null</c> if no savings account exists.
        /// </summary>
        public SavingsAccount? LinkedSavings { get; set; }

        // ----------------------------------------------------------------
        // Constructor
        // ----------------------------------------------------------------

        /// <summary>
        /// Creates a new checking account with an optional opening balance.
        /// </summary>
        /// <param name="initialBalance">Starting balance (default 0).</param>
        public CheckingAccount(decimal initialBalance = 0) : base(initialBalance) { }

        // ----------------------------------------------------------------
        // Overridden methods
        // ----------------------------------------------------------------

        /// <summary>
        /// Attempts the withdrawal using a three-tier strategy:
        /// <list type="number">
        ///   <item><description>Checking balance alone covers the amount.</description></item>
        ///   <item><description>
        ///     Combined checking + savings balance covers the amount
        ///     (overdraft protection — deficit pulled from savings).
        ///   </description></item>
        ///   <item><description>Insufficient funds — returns <c>false</c>.</description></item>
        /// </list>
        /// </summary>
        /// <param name="amount">The amount to withdraw; must be greater than zero.</param>
        /// <returns>
        /// <c>true</c> if the withdrawal succeeded (either from checking alone
        /// or with savings overdraft coverage); <c>false</c> otherwise.
        /// </returns>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when <paramref name="amount"/> is zero or negative.
        /// </exception>
        public override bool Withdraw(decimal amount)
        {
            if (amount <= 0)
                throw new ArgumentOutOfRangeException(
                    nameof(amount), "Withdrawal amount must be greater than zero.");

            // Case 1: Checking balance is sufficient on its own.
            if (Balance >= amount)
            {
                Balance -= amount;
                return true;
            }

            // Case 2: Overdraft — combined balance covers the withdrawal.
            bool overdraftAvailable = LinkedSavings != null
                && (Balance + LinkedSavings.Balance) >= amount;

            if (overdraftAvailable)
            {
                decimal deficit = amount - Balance;
                Balance = 0;
                LinkedSavings!.Withdraw(deficit);   // SavingsAccount.Withdraw (polymorphic)
                return true;
            }

            // Case 3: Funds are insufficient even with overdraft coverage.
            return false;
        }
    }
}
