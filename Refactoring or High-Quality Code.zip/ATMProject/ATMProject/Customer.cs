namespace ATMProject
{
    /// <summary>
    /// Represents a bank customer who can authenticate with the ATM.
    ///
    /// <para>
    /// Encapsulates personal identity (name, PIN) and references to
    /// both account objects. The <see cref="FullName"/> computed property
    /// keeps name formatting logic in one place.
    /// </para>
    ///
    /// <para>
    /// <b>Note on PIN storage:</b> In a production system the PIN would
    /// be stored as a salted hash, never as plain text. Plain-integer storage
    /// is used here solely for academic demonstration purposes.
    /// </para>
    /// </summary>
    public class Customer
    {
        // ----------------------------------------------------------------
        // Identity properties
        // ----------------------------------------------------------------

        /// <summary>Database primary key for this customer record.</summary>
        public int CustomerId { get; set; }

        /// <summary>Customer's given (first) name.</summary>
        public string FirstName { get; set; } = string.Empty;

        /// <summary>Customer's family (last) name.</summary>
        public string LastName { get; set; } = string.Empty;

        /// <summary>
        /// The customer's numeric PIN used for ATM authentication.
        /// Should never be displayed or logged in a production environment.
        /// </summary>
        public int Pin { get; set; }

        // ----------------------------------------------------------------
        // Account references
        // ----------------------------------------------------------------

        /// <summary>
        /// The customer's checking account, or <c>null</c> if none exists.
        /// </summary>
        public CheckingAccount? Checking { get; set; }

        /// <summary>
        /// The customer's savings account, or <c>null</c> if none exists.
        /// </summary>
        public SavingsAccount? Savings { get; set; }

        // ----------------------------------------------------------------
        // Computed properties
        // ----------------------------------------------------------------

        /// <summary>
        /// Returns the customer's full name formatted as "FirstName LastName".
        /// </summary>
        public string FullName => $"{FirstName} {LastName}";
    }
}
