namespace ATMProject
{
    /// <summary>
    /// Abstract base class representing a generic bank account.
    /// Encapsulates the core state (Balance, AccountId, CustomerId) and
    /// defines the contract that all concrete account types must fulfill.
    ///
    /// <para>
    /// OOP principles demonstrated:
    /// <list type="bullet">
    ///   <item><description>
    ///     <b>Abstraction</b> — AccountType is abstract, forcing each subclass
    ///     to declare its own human-readable type label.
    ///   </description></item>
    ///   <item><description>
    ///     <b>Encapsulation</b> — Balance is exposed only through validated
    ///     Deposit / Withdraw methods; the setter is protected so only this
    ///     class and its children may mutate the balance directly.
    ///   </description></item>
    ///   <item><description>
    ///     <b>Polymorphism</b> — Deposit and Withdraw are virtual, allowing
    ///     subclasses (e.g., CheckingAccount) to override the behaviour
    ///     while sharing the common validation logic.
    ///   </description></item>
    /// </list>
    /// </para>
    /// </summary>
    public abstract class Account
    {
        // ----------------------------------------------------------------
        // Properties
        // ----------------------------------------------------------------

        /// <summary>Database primary key for this account row.</summary>
        public int AccountId { get; set; }

        /// <summary>Foreign key linking this account to its owner.</summary>
        public int CustomerId { get; set; }

        /// <summary>
        /// Current account balance.
        /// The setter is protected so that balance changes must flow through
        /// Deposit or Withdraw, preserving encapsulation.
        /// </summary>
        public decimal Balance { get; protected set; }

        /// <summary>Human-readable account type label used throughout the UI.</summary>
        public abstract string AccountType { get; }

        // ----------------------------------------------------------------
        // Constructor
        // ----------------------------------------------------------------

        /// <summary>
        /// Initialises the account with the provided opening balance.
        /// </summary>
        /// <param name="initialBalance">
        /// Starting balance; must be zero or greater.
        /// </param>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when <paramref name="initialBalance"/> is negative.
        /// </exception>
        protected Account(decimal initialBalance = 0)
        {
            if (initialBalance < 0)
                throw new ArgumentOutOfRangeException(
                    nameof(initialBalance), "Opening balance cannot be negative.");

            Balance = initialBalance;
        }

        // ----------------------------------------------------------------
        // Public methods
        // ----------------------------------------------------------------

        /// <summary>
        /// Deposits a positive amount into the account.
        /// </summary>
        /// <param name="amount">The amount to deposit; must be greater than zero.</param>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when <paramref name="amount"/> is zero or negative.
        /// </exception>
        public virtual void Deposit(decimal amount)
        {
            if (amount <= 0)
                throw new ArgumentOutOfRangeException(
                    nameof(amount), "Deposit amount must be greater than zero.");

            Balance += amount;
        }

        /// <summary>
        /// Attempts to withdraw the specified amount from the account.
        /// </summary>
        /// <param name="amount">The amount to withdraw; must be greater than zero.</param>
        /// <returns>
        /// <c>true</c> if the withdrawal succeeded; <c>false</c> if funds were insufficient.
        /// </returns>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when <paramref name="amount"/> is zero or negative.
        /// </exception>
        public virtual bool Withdraw(decimal amount)
        {
            if (amount <= 0)
                throw new ArgumentOutOfRangeException(
                    nameof(amount), "Withdrawal amount must be greater than zero.");

            if (Balance < amount)
                return false;

            Balance -= amount;
            return true;
        }

        /// <summary>
        /// Allows the database layer to restore a persisted balance without
        /// routing through the business-logic methods.
        /// </summary>
        /// <param name="restoredBalance">The balance value read from the database.</param>
        internal void RestoreBalance(decimal restoredBalance) => Balance = restoredBalance;
    }
}
