namespace ATMProject
{
    /// <summary>
    /// Application entry point.
    /// Initialises the database and launches the login form.
    /// </summary>
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the ATM application.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            // Ensure the SQLite database and all tables exist before any
            // form attempts a database call.
            SQLHelper.InitializeDatabase();

            ApplicationConfiguration.Initialize();
            Application.Run(new LoginForm());
        }
    }
}
