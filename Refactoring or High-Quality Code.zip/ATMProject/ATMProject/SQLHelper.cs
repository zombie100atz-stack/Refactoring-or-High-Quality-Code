using System.Data.SQLite;

namespace ATMProject
{
    /// <summary>
    /// Static data-access layer.  All database interaction for the ATM
    /// application is confined to this single class (Single Responsibility).
    ///
    /// <para>
    /// Every public method accepts or returns domain objects
    /// (<see cref="Customer"/>, <see cref="Account"/>) rather than raw
    /// primitives, keeping database concerns isolated from business logic.
    /// </para>
    ///
    /// <para>
    /// All SQL commands use parameterised queries to prevent SQL injection.
    /// </para>
    /// </summary>
    public static class SQLHelper
    {
        // ----------------------------------------------------------------
        // Private constants / fields
        // ----------------------------------------------------------------

        private static readonly string DatabasePath = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, "atm.db");

        private static string ConnectionString =>
            $"Data Source={DatabasePath};Version=3;";

        // ----------------------------------------------------------------
        // Schema initialisation
        // ----------------------------------------------------------------

        /// <summary>
        /// Creates the SQLite database file and all required tables if they
        /// do not already exist.  Seeds two demo accounts on first run.
        /// Must be called once at application startup before any other method.
        /// </summary>
        public static void InitializeDatabase()
        {
            if (!File.Exists(DatabasePath))
                SQLiteConnection.CreateFile(DatabasePath);

            using var connection = new SQLiteConnection(ConnectionString);
            connection.Open();

            CreateTablesIfAbsent(connection);
            SeedDemoDataIfEmpty(connection);
        }

        /// <summary>Creates all required tables using IF NOT EXISTS guards.</summary>
        private static void CreateTablesIfAbsent(SQLiteConnection connection)
        {
            ExecuteNonQuery(connection, @"
                CREATE TABLE IF NOT EXISTS Customers (
                    CustomerId  INTEGER PRIMARY KEY AUTOINCREMENT,
                    FirstName   TEXT    NOT NULL,
                    LastName    TEXT    NOT NULL,
                    Pin         INTEGER NOT NULL
                );");

            ExecuteNonQuery(connection, @"
                CREATE TABLE IF NOT EXISTS Accounts (
                    AccountId   INTEGER PRIMARY KEY AUTOINCREMENT,
                    CustomerId  INTEGER NOT NULL,
                    AccountType TEXT    NOT NULL,
                    Balance     REAL    NOT NULL DEFAULT 0,
                    FOREIGN KEY(CustomerId) REFERENCES Customers(CustomerId)
                );");

            ExecuteNonQuery(connection, @"
                CREATE TABLE IF NOT EXISTS TransactionLog (
                    LogId      INTEGER PRIMARY KEY AUTOINCREMENT,
                    AccountId  INTEGER NOT NULL,
                    TxType     TEXT    NOT NULL,
                    Amount     REAL    NOT NULL,
                    NewBalance REAL    NOT NULL,
                    TxDate     TEXT    NOT NULL
                );");
        }

        /// <summary>
        /// Inserts two demo customers only when the Customers table is empty.
        /// Demo credentials: ID 1 / PIN 1234  and  ID 2 / PIN 5678.
        /// </summary>
        private static void SeedDemoDataIfEmpty(SQLiteConnection connection)
        {
            long customerCount = (long)new SQLiteCommand(
                "SELECT COUNT(*) FROM Customers;", connection).ExecuteScalar()!;

            if (customerCount > 0)
                return;

            InsertDemoCustomer(connection, "Jane", "Smith", 1234, 1500.00m, 3200.00m);
            InsertDemoCustomer(connection, "John", "Doe",   5678,  800.00m,  450.00m);
        }

        private static void InsertDemoCustomer(
            SQLiteConnection connection,
            string firstName,
            string lastName,
            int pin,
            decimal checkingBalance,
            decimal savingsBalance)
        {
            var insertCustomer = new SQLiteCommand(
                "INSERT INTO Customers (FirstName, LastName, Pin) VALUES (@fn, @ln, @pin);",
                connection);
            insertCustomer.Parameters.AddWithValue("@fn",  firstName);
            insertCustomer.Parameters.AddWithValue("@ln",  lastName);
            insertCustomer.Parameters.AddWithValue("@pin", pin);
            insertCustomer.ExecuteNonQuery();

            long customerId = connection.LastInsertRowId;

            InsertAccount(connection, customerId, "Checking", checkingBalance);
            InsertAccount(connection, customerId, "Savings",  savingsBalance);
        }

        private static void InsertAccount(
            SQLiteConnection connection,
            long customerId,
            string accountType,
            decimal balance)
        {
            var cmd = new SQLiteCommand(
                "INSERT INTO Accounts (CustomerId, AccountType, Balance) " +
                "VALUES (@cid, @type, @bal);",
                connection);
            cmd.Parameters.AddWithValue("@cid",  customerId);
            cmd.Parameters.AddWithValue("@type", accountType);
            cmd.Parameters.AddWithValue("@bal",  (double)balance);
            cmd.ExecuteNonQuery();
        }

        // ----------------------------------------------------------------
        // Authentication
        // ----------------------------------------------------------------

        /// <summary>
        /// Authenticates a customer by customer ID and PIN.
        /// </summary>
        /// <param name="customerId">The customer's numeric ID.</param>
        /// <param name="pin">The PIN entered at the ATM keypad.</param>
        /// <returns>
        /// A fully populated <see cref="Customer"/> object (including both
        /// account references) on success, or <c>null</c> if the credentials
        /// are invalid.
        /// </returns>
        public static Customer? Login(int customerId, int pin)
        {
            using var connection = new SQLiteConnection(ConnectionString);
            connection.Open();

            var cmd = new SQLiteCommand(
                "SELECT CustomerId, FirstName, LastName, Pin " +
                "FROM Customers " +
                "WHERE CustomerId = @id AND Pin = @pin;",
                connection);
            cmd.Parameters.AddWithValue("@id",  customerId);
            cmd.Parameters.AddWithValue("@pin", pin);

            using var reader = cmd.ExecuteReader();

            if (!reader.Read())
                return null;    // No matching credentials found.

            var customer = new Customer
            {
                CustomerId = reader.GetInt32(0),
                FirstName  = reader.GetString(1),
                LastName   = reader.GetString(2),
                Pin        = reader.GetInt32(3)
            };

            LoadAccountsForCustomer(customer, connection);

            return customer;
        }

        // ----------------------------------------------------------------
        // Account retrieval
        // ----------------------------------------------------------------

        /// <summary>
        /// Loads both account objects for the given customer and assigns
        /// them to the customer's <see cref="Customer.Checking"/> and
        /// <see cref="Customer.Savings"/> properties.
        /// Also links the savings account to checking for overdraft use.
        /// </summary>
        private static void LoadAccountsForCustomer(
            Customer customer, SQLiteConnection connection)
        {
            var cmd = new SQLiteCommand(
                "SELECT AccountId, CustomerId, AccountType, Balance " +
                "FROM Accounts WHERE CustomerId = @id;",
                connection);
            cmd.Parameters.AddWithValue("@id", customer.CustomerId);

            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                int     accountId  = reader.GetInt32(0);
                int     ownerId    = reader.GetInt32(1);
                string  type       = reader.GetString(2);
                decimal balance    = (decimal)reader.GetDouble(3);

                if (type == "Checking")
                {
                    customer.Checking = new CheckingAccount();
                    customer.Checking.AccountId  = accountId;
                    customer.Checking.CustomerId = ownerId;
                    customer.Checking.RestoreBalance(balance);
                }
                else if (type == "Savings")
                {
                    customer.Savings = new SavingsAccount();
                    customer.Savings.AccountId  = accountId;
                    customer.Savings.CustomerId = ownerId;
                    customer.Savings.RestoreBalance(balance);
                }
            }

            // Link savings to checking so overdraft protection is available.
            if (customer.Checking != null)
                customer.Checking.LinkedSavings = customer.Savings;
        }

        // ----------------------------------------------------------------
        // Balance persistence
        // ----------------------------------------------------------------

        /// <summary>
        /// Writes the current in-memory balance of <paramref name="account"/>
        /// back to the database.
        /// Accepts any <see cref="Account"/> subtype (polymorphic).
        /// </summary>
        /// <param name="account">The account whose balance should be saved.</param>
        public static void UpdateAccountBalance(Account account)
        {
            using var connection = new SQLiteConnection(ConnectionString);
            connection.Open();

            var cmd = new SQLiteCommand(
                "UPDATE Accounts SET Balance = @balance WHERE AccountId = @id;",
                connection);
            cmd.Parameters.AddWithValue("@balance", (double)account.Balance);
            cmd.Parameters.AddWithValue("@id",       account.AccountId);
            cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// Saves both account balances for the given customer in a single call.
        /// Useful after operations that may affect both accounts (e.g., overdraft).
        /// </summary>
        /// <param name="customer">The customer whose accounts should be persisted.</param>
        public static void SaveCustomerAccounts(Customer customer)
        {
            if (customer.Checking != null)
                UpdateAccountBalance(customer.Checking);

            if (customer.Savings != null)
                UpdateAccountBalance(customer.Savings);
        }

        // ----------------------------------------------------------------
        // Transaction log
        // ----------------------------------------------------------------

        /// <summary>
        /// Appends a transaction record to the log for audit and history display.
        /// </summary>
        /// <param name="account">
        /// The account involved in the transaction.
        /// </param>
        /// <param name="transactionType">
        /// A short descriptor such as "Deposit", "Withdraw",
        /// "Transfer-Out", or "Transfer-In".
        /// </param>
        /// <param name="amount">The dollar amount of the transaction.</param>
        public static void LogTransaction(
            Account account, string transactionType, decimal amount)
        {
            using var connection = new SQLiteConnection(ConnectionString);
            connection.Open();

            var cmd = new SQLiteCommand(@"
                INSERT INTO TransactionLog
                    (AccountId, TxType, Amount, NewBalance, TxDate)
                VALUES
                    (@aid, @type, @amt, @bal, @date);",
                connection);
            cmd.Parameters.AddWithValue("@aid",  account.AccountId);
            cmd.Parameters.AddWithValue("@type", transactionType);
            cmd.Parameters.AddWithValue("@amt",  (double)amount);
            cmd.Parameters.AddWithValue("@bal",  (double)account.Balance);
            cmd.Parameters.AddWithValue("@date", DateTime.Now.ToString("o"));
            cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// Returns the most recent transaction log entries for one account,
        /// formatted as display strings.
        /// </summary>
        /// <param name="account">The account whose history is requested.</param>
        /// <param name="maxRows">
        /// Maximum number of rows to return (default 10).
        /// </param>
        /// <returns>
        /// A list of formatted strings, newest first.
        /// Returns an empty list when no transactions have been recorded.
        /// </returns>
        public static List<string> GetTransactionHistory(Account account, int maxRows = 10)
        {
            var results = new List<string>();

            using var connection = new SQLiteConnection(ConnectionString);
            connection.Open();

            var cmd = new SQLiteCommand(@"
                SELECT TxType, Amount, NewBalance, TxDate
                FROM   TransactionLog
                WHERE  AccountId = @aid
                ORDER  BY LogId DESC
                LIMIT  @max;",
                connection);
            cmd.Parameters.AddWithValue("@aid", account.AccountId);
            cmd.Parameters.AddWithValue("@max", maxRows);

            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                string   transactionType = reader.GetString(0);
                double   amount          = reader.GetDouble(1);
                double   newBalance      = reader.GetDouble(2);
                DateTime transactionDate = DateTime.Parse(reader.GetString(3));

                results.Add(
                    $"{transactionDate:MM/dd/yy HH:mm}  " +
                    $"{transactionType,-12}  " +
                    $"${amount,9:F2}  " +
                    $"Bal: ${newBalance:F2}");
            }

            return results;
        }

        // ----------------------------------------------------------------
        // Private utility
        // ----------------------------------------------------------------

        /// <summary>Executes a non-query SQL string on an open connection.</summary>
        private static void ExecuteNonQuery(SQLiteConnection connection, string sql)
            => new SQLiteCommand(sql, connection).ExecuteNonQuery();
    }
}
