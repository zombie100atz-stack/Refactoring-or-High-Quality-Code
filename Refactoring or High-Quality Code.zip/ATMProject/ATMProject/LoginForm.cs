using System.Drawing;
using System.Windows.Forms;

namespace ATMProject
{
    /// <summary>
    /// The initial ATM screen presented to the user.
    /// Collects a customer ID and PIN, validates them against the database,
    /// and — on success — opens the main <see cref="ATMForm"/>.
    ///
    /// <para>
    /// Input validation is performed in two layers:
    /// <list type="number">
    ///   <item><description>
    ///     <b>KeyPress handler</b> — prevents non-numeric characters from
    ///     being entered in either text field.
    ///   </description></item>
    ///   <item><description>
    ///     <b>Login handler</b> — confirms the fields are non-empty and
    ///     that the parsed values match a record in the database.
    ///   </description></item>
    /// </list>
    /// </para>
    /// </summary>
    public class LoginForm : Form
    {
        // ----------------------------------------------------------------
        // UI control fields
        // ----------------------------------------------------------------

        private Panel   pnlCard       = null!;
        private Label   lblTitle      = null!;
        private Label   lblSubtitle   = null!;
        private Label   lblCustomerId = null!;
        private TextBox txtCustomerId = null!;
        private Label   lblPin        = null!;
        private TextBox txtPin        = null!;
        private Button  btnLogin      = null!;
        private Label   lblError      = null!;
        private Label   lblDemoHint   = null!;

        // ----------------------------------------------------------------
        // Constructor
        // ----------------------------------------------------------------

        /// <summary>Initialises the login form and all its controls.</summary>
        public LoginForm()
        {
            InitializeComponent();
        }

        // ----------------------------------------------------------------
        // UI construction
        // ----------------------------------------------------------------

        private void InitializeComponent()
        {
            Text            = "ATM — Please Insert Card";
            Size            = new Size(480, 540);
            StartPosition   = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox     = false;
            BackColor       = Color.FromArgb(30, 30, 45);
            Font            = new Font("Segoe UI", 10f);

            BuildCardPanel();
            BuildHeaderControls();
            BuildInputControls();
            BuildLoginButton();
            BuildStatusLabels();
        }

        private void BuildCardPanel()
        {
            pnlCard = new Panel
            {
                Size      = new Size(360, 400),
                Location  = new Point(60, 70),
                BackColor = Color.FromArgb(45, 45, 65)
            };
            pnlCard.Paint += (s, e) =>
            {
                using var pen = new Pen(Color.FromArgb(80, 200, 255), 2);
                e.Graphics.DrawRoundRect(
                    pen, new Rectangle(1, 1, pnlCard.Width - 3, pnlCard.Height - 3), 12);
            };
            Controls.Add(pnlCard);
        }

        private void BuildHeaderControls()
        {
            lblTitle = new Label
            {
                Text      = "🏦  SecureBank ATM",
                Font      = new Font("Segoe UI", 16f, FontStyle.Bold),
                ForeColor = Color.FromArgb(80, 200, 255),
                AutoSize  = false,
                Size      = new Size(340, 40),
                Location  = new Point(10, 20),
                TextAlign = ContentAlignment.MiddleCenter
            };
            pnlCard.Controls.Add(lblTitle);

            lblSubtitle = new Label
            {
                Text      = "Enter your Customer ID and PIN",
                ForeColor = Color.LightGray,
                AutoSize  = false,
                Size      = new Size(340, 22),
                Location  = new Point(10, 64),
                TextAlign = ContentAlignment.MiddleCenter
            };
            pnlCard.Controls.Add(lblSubtitle);

            var divider = new Panel
            {
                Size      = new Size(300, 1),
                Location  = new Point(30, 92),
                BackColor = Color.FromArgb(80, 200, 255)
            };
            pnlCard.Controls.Add(divider);
        }

        private void BuildInputControls()
        {
            // ----- Customer ID -----
            lblCustomerId = new Label
            {
                Text      = "Customer Number",
                ForeColor = Color.LightGray,
                AutoSize  = true,
                Location  = new Point(40, 112)
            };
            pnlCard.Controls.Add(lblCustomerId);

            txtCustomerId = CreateStyledTextBox(new Point(40, 134), maxLength: 6);
            txtCustomerId.KeyPress += NumericOnly_KeyPress;
            pnlCard.Controls.Add(txtCustomerId);

            // ----- PIN -----
            lblPin = new Label
            {
                Text      = "PIN",
                ForeColor = Color.LightGray,
                AutoSize  = true,
                Location  = new Point(40, 176)
            };
            pnlCard.Controls.Add(lblPin);

            txtPin = CreateStyledTextBox(new Point(40, 198), maxLength: 6);
            txtPin.PasswordChar = '●';
            txtPin.KeyPress    += NumericOnly_KeyPress;
            txtPin.KeyDown     += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                    btnLogin.PerformClick();
            };
            pnlCard.Controls.Add(txtPin);
        }

        private void BuildLoginButton()
        {
            btnLogin = new Button
            {
                Text      = "LOG IN",
                Size      = new Size(280, 42),
                Location  = new Point(40, 254),
                BackColor = Color.FromArgb(0, 150, 255),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font      = new Font("Segoe UI", 11f, FontStyle.Bold),
                Cursor    = Cursors.Hand
            };
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.Click += BtnLogin_Click;
            pnlCard.Controls.Add(btnLogin);
        }

        private void BuildStatusLabels()
        {
            lblError = new Label
            {
                Text      = string.Empty,
                ForeColor = Color.Tomato,
                AutoSize  = false,
                Size      = new Size(280, 22),
                Location  = new Point(40, 304),
                TextAlign = ContentAlignment.MiddleCenter
            };
            pnlCard.Controls.Add(lblError);

            lblDemoHint = new Label
            {
                Text      = "Demo: ID 1 / PIN 1234  |  ID 2 / PIN 5678",
                ForeColor = Color.FromArgb(120, 120, 140),
                AutoSize  = false,
                Size      = new Size(340, 22),
                Location  = new Point(10, 350),
                TextAlign = ContentAlignment.MiddleCenter,
                Font      = new Font("Segoe UI", 8.5f)
            };
            pnlCard.Controls.Add(lblDemoHint);
        }

        // ----------------------------------------------------------------
        // Event handlers
        // ----------------------------------------------------------------

        /// <summary>
        /// Blocks any non-digit, non-control keystroke so that both the
        /// customer-ID and PIN fields accept only numeric input.
        /// </summary>
        private void NumericOnly_KeyPress(object? sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        /// <summary>
        /// Validates user input and attempts to authenticate against the
        /// database. Opens <see cref="ATMForm"/> on success or displays an
        /// inline error message on failure.
        /// </summary>
        private void BtnLogin_Click(object? sender, EventArgs e)
        {
            lblError.Text = string.Empty;

            if (!TryGetCustomerId(out int customerId) || !TryGetPin(out int pin))
                return;

            Customer? customer = SQLHelper.Login(customerId, pin);

            if (customer == null)
            {
                lblError.Text = "Invalid credentials. Please try again.";
                txtPin.Clear();
                txtPin.Focus();
                return;
            }

            OpenAtmForm(customer);
        }

        // ----------------------------------------------------------------
        // Input validation helpers
        // ----------------------------------------------------------------

        /// <summary>
        /// Tries to parse a positive integer customer ID from the text field.
        /// Sets focus and shows an error on failure.
        /// </summary>
        private bool TryGetCustomerId(out int customerId)
        {
            if (int.TryParse(txtCustomerId.Text.Trim(), out customerId) && customerId > 0)
                return true;

            lblError.Text = "Please enter a valid customer number.";
            txtCustomerId.Focus();
            return false;
        }

        /// <summary>
        /// Tries to parse a positive integer PIN from the PIN text field.
        /// Sets focus and shows an error on failure.
        /// </summary>
        private bool TryGetPin(out int pin)
        {
            if (int.TryParse(txtPin.Text.Trim(), out pin) && pin > 0)
                return true;

            lblError.Text = "Please enter your PIN.";
            txtPin.Focus();
            return false;
        }

        // ----------------------------------------------------------------
        // Navigation
        // ----------------------------------------------------------------

        /// <summary>
        /// Opens the main ATM form for the authenticated customer and hides
        /// this login form until the ATM form is closed.
        /// </summary>
        private void OpenAtmForm(Customer customer)
        {
            var atmForm = new ATMForm(customer);
            atmForm.FormClosed += (s, e) => Close();
            atmForm.Show();
            Hide();
        }

        // ----------------------------------------------------------------
        // UI factory helpers
        // ----------------------------------------------------------------

        /// <summary>
        /// Creates a consistently styled text box used for credential entry.
        /// </summary>
        /// <param name="location">Position inside the card panel.</param>
        /// <param name="maxLength">Maximum number of characters allowed.</param>
        private static TextBox CreateStyledTextBox(Point location, int maxLength)
        {
            return new TextBox
            {
                Size        = new Size(280, 28),
                Location    = location,
                BackColor   = Color.FromArgb(60, 60, 80),
                ForeColor   = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Font        = new Font("Segoe UI", 12f),
                MaxLength   = maxLength
            };
        }
    }

    // ----------------------------------------------------------------
    // Graphics extension — rounded rectangle helper
    // ----------------------------------------------------------------

    /// <summary>
    /// Extension methods that add rounded-rectangle drawing to
    /// <see cref="System.Drawing.Graphics"/>.
    /// </summary>
    internal static class GraphicsExtensions
    {
        /// <summary>
        /// Draws a rectangle with rounded corners using the specified pen.
        /// </summary>
        /// <param name="graphics">The graphics surface to draw on.</param>
        /// <param name="pen">Pen that defines stroke color and width.</param>
        /// <param name="bounds">The bounding rectangle.</param>
        /// <param name="cornerRadius">Radius of each corner arc in pixels.</param>
        public static void DrawRoundRect(
            this System.Drawing.Graphics graphics,
            Pen pen,
            Rectangle bounds,
            int cornerRadius)
        {
            int diameter = cornerRadius * 2;

            using var path = new System.Drawing.Drawing2D.GraphicsPath();
            path.AddArc(bounds.X,                bounds.Y,                 diameter, diameter, 180, 90);
            path.AddArc(bounds.Right - diameter, bounds.Y,                 diameter, diameter, 270, 90);
            path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter,   0, 90);
            path.AddArc(bounds.X,                bounds.Bottom - diameter, diameter, diameter,  90, 90);
            path.CloseFigure();

            graphics.DrawPath(pen, path);
        }
    }
}
