namespace ATMProject
{
    /// <summary>
    /// A standard savings account.
    ///
    /// <para>
    /// Inherits deposit and withdrawal behaviour from <see cref="Account"/>
    /// without modification — base-class logic is correct as-is.
    /// No overdraft protection is provided: withdrawals simply fail
    /// when the balance is insufficient.
    /// </para>
    ///
    /// <para>
    /// Demonstrates <b>inheritance</b>: SavingsAccount reuses all of
    /// Account's validated Deposit / Withdraw logic by extending the
    /// abstract base class without duplicating any code.
    /// </para>
    /// </summary>
    public class SavingsAccount : Account
    {
        /// <inheritdoc/>
        public override string AccountType => "Savings";

        /// <summary>
        /// Creates a new savings account with an optional opening balance.
        /// </summary>
        /// <param name="initialBalance">Starting balance (default 0).</param>
        public SavingsAccount(decimal initialBalance = 0) : base(initialBalance) { }
    }
}
