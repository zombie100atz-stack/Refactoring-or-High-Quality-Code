using System.Drawing;
using System.Windows.Forms;

namespace ATMProject
{
    /// <summary>
    /// The main ATM screen displayed after a successful login.
    ///
    /// <para>
    /// Supported operations: view balances, deposit, withdraw, transfer
    /// between accounts, view transaction history, and logout.
    /// </para>
    ///
    /// <para>
    /// The form works exclusively with <see cref="Account"/> objects
    /// (polymorphic), so the same UI code handles both
    /// <see cref="CheckingAccount"/> and <see cref="SavingsAccount"/>
    /// without branching on the concrete type.
    /// </para>
    /// </summary>
    public class ATMForm : Form
    {
        // ----------------------------------------------------------------
        // Private enum — tracks which operation panel is active
        // ----------------------------------------------------------------

        private enum OperationMode { Balance, Deposit, Withdraw, Transfer, History }

        // ----------------------------------------------------------------
        // State
        // ----------------------------------------------------------------

        private readonly Customer _customer;
        private OperationMode _currentMode = OperationMode.Balance;

        // ----------------------------------------------------------------
        // Controls — header
        // ----------------------------------------------------------------

        private Label lblWelcome  = null!;
        private Label lblDateTime = null!;
        private Timer tmrClock    = null!;

        // ----------------------------------------------------------------
        // Controls — balance cards
        // ----------------------------------------------------------------

        private Panel pnlChecking      = null!;
        private Label lblCheckingTitle = null!;
        private Label lblCheckingBal   = null!;

        private Panel pnlSavings      = null!;
        private Label lblSavingsTitle = null!;
        private Label lblSavingsBal   = null!;

        // ----------------------------------------------------------------
        // Controls — action buttons
        // ----------------------------------------------------------------

        private Button btnBalance  = null!;
        private Button btnDeposit  = null!;
        private Button btnWithdraw = null!;
        private Button btnTransfer = null!;
        private Button btnHistory  = null!;
        private Button btnLogout   = null!;

        // ----------------------------------------------------------------
        // Controls — operation panel
        // ----------------------------------------------------------------

        private Panel    pnlOperation    = null!;
        private Label    lblOpTitle      = null!;
        private Label    lblAccountLabel = null!;
        private ComboBox cmbAccount      = null!;
        private Label    lblAmountLabel  = null!;
        private TextBox  txtAmount       = null!;
        private Label    lblToAccountLbl = null!;
        private ComboBox cmbToAccount    = null!;
        private Button   btnExecute      = null!;
        private Label    lblOpResult     = null!;

        // ----------------------------------------------------------------
        // Constructor
        // ----------------------------------------------------------------

        /// <summary>
        /// Initialises the ATM form for the authenticated customer.
        /// </summary>
        /// <param name="customer">
        /// The customer object returned by a successful login.
        /// Must not be <c>null</c>.
        /// </param>
        public ATMForm(Customer customer)
        {
            _customer = customer ?? throw new ArgumentNullException(nameof(customer));
            InitializeComponent();
            RefreshBalanceCards();
            ShowOperationPanel(OperationMode.Balance);
        }

        // ----------------------------------------------------------------
        // UI construction
        // ----------------------------------------------------------------

        private void InitializeComponent()
        {
            Text            = $"SecureBank ATM — Welcome {_customer.FullName}";
            Size            = new Size(700, 600);
            StartPosition   = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox     = false;
            BackColor       = Color.FromArgb(30, 30, 45);
            Font            = new Font("Segoe UI", 10f);

            BuildHeader();
            BuildBalanceCards();
            BuildActionButtons();
            BuildOperationPanel();
        }

        private void BuildHeader()
        {
            lblWelcome = new Label
            {
                Text      = $"Welcome, {_customer.FullName}",
                Font      = new Font("Segoe UI", 14f, FontStyle.Bold),
                ForeColor = Color.FromArgb(80, 200, 255),
                AutoSize  = false,
                Size      = new Size(430, 32),
                Location  = new Point(20, 14)
            };
            Controls.Add(lblWelcome);

            lblDateTime = new Label
            {
                ForeColor = Color.LightGray,
                AutoSize  = false,
                Size      = new Size(220, 22),
                Location  = new Point(460, 18),
                TextAlign = ContentAlignment.MiddleRight
            };
            Controls.Add(lblDateTime);

            tmrClock       = new Timer { Interval = 1000 };
            tmrClock.Tick += (s, e) => UpdateClock();
            tmrClock.Start();
            UpdateClock();

            var divider = new Panel
            {
                Size      = new Size(660, 1),
                Location  = new Point(20, 50),
                BackColor = Color.FromArgb(80, 200, 255)
            };
            Controls.Add(divider);
        }

        private void UpdateClock()
            => lblDateTime.Text = DateTime.Now.ToString("ddd MM/dd/yyyy  hh:mm tt");

        private void BuildBalanceCards()
        {
            pnlChecking = CreateBalanceCardPanel(new Point(20, 62), Color.FromArgb(0, 120, 200));
            Controls.Add(pnlChecking);
            lblCheckingTitle = (Label)pnlChecking.Controls[0];
            lblCheckingBal   = (Label)pnlChecking.Controls[1];
            lblCheckingTitle.Text = "Checking Account";

            pnlSavings = CreateBalanceCardPanel(new Point(352, 62), Color.FromArgb(0, 160, 100));
            Controls.Add(pnlSavings);
            lblSavingsTitle = (Label)pnlSavings.Controls[0];
            lblSavingsBal   = (Label)pnlSavings.Controls[1];
            lblSavingsTitle.Text = "Savings Account";
        }

        private void BuildActionButtons()
        {
            const int ButtonX      = 20;
            const int ButtonStartY = 152;
            const int ButtonWidth  = 135;
            const int ButtonHeight = 42;
            const int ButtonGap    = 12;

            int Step(int index) => ButtonStartY + (ButtonHeight + ButtonGap) * index;

            btnBalance  = CreateActionButton("💰 Balance",  new Point(ButtonX, Step(0)));
            btnDeposit  = CreateActionButton("⬆ Deposit",   new Point(ButtonX, Step(1)));
            btnWithdraw = CreateActionButton("⬇ Withdraw",  new Point(ButtonX, Step(2)));
            btnTransfer = CreateActionButton("⇄ Transfer",  new Point(ButtonX, Step(3)));
            btnHistory  = CreateActionButton("📋 History",  new Point(ButtonX, Step(4)));
            btnLogout   = CreateActionButton("🚪 Logout",   new Point(ButtonX, Step(5)));

            btnBalance.BackColor = Color.FromArgb(0, 130, 200);
            btnLogout.BackColor  = Color.FromArgb(180, 50, 50);

            btnBalance.Click  += (s, e) => ShowOperationPanel(OperationMode.Balance);
            btnDeposit.Click  += (s, e) => ShowOperationPanel(OperationMode.Deposit);
            btnWithdraw.Click += (s, e) => ShowOperationPanel(OperationMode.Withdraw);
            btnTransfer.Click += (s, e) => ShowOperationPanel(OperationMode.Transfer);
            btnHistory.Click  += (s, e) => ShowOperationPanel(OperationMode.History);
            btnLogout.Click   += (s, e) => Logout();

            Button[] allButtons = { btnBalance, btnDeposit, btnWithdraw,
                                    btnTransfer, btnHistory, btnLogout };
            foreach (var button in allButtons)
                Controls.Add(button);
        }

        private void BuildOperationPanel()
        {
            pnlOperation = new Panel
            {
                Size      = new Size(510, 380),
                Location  = new Point(168, 148),
                BackColor = Color.FromArgb(45, 45, 65)
            };
            Controls.Add(pnlOperation);

            lblOpTitle = CreateStyledLabel(
                string.Empty, new Font("Segoe UI", 12f, FontStyle.Bold),
                Color.FromArgb(80, 200, 255), new Point(20, 16));
            pnlOperation.Controls.Add(lblOpTitle);

            lblAccountLabel = CreateStyledLabel("Account:",  null, Color.LightGray, new Point(20, 60));
            pnlOperation.Controls.Add(lblAccountLabel);

            cmbAccount = CreateStyledComboBox(new Point(150, 57));
            pnlOperation.Controls.Add(cmbAccount);

            lblAmountLabel = CreateStyledLabel("Amount: $", null, Color.LightGray, new Point(20, 100));
            pnlOperation.Controls.Add(lblAmountLabel);

            txtAmount = new TextBox
            {
                Size        = new Size(220, 26),
                Location    = new Point(150, 97),
                BackColor   = Color.FromArgb(60, 60, 80),
                ForeColor   = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Font        = new Font("Segoe UI", 11f)
            };
            txtAmount.KeyPress += (s, e) =>
            {
                // Allow only digits, a single decimal point, and control keys.
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                    e.Handled = true;
            };
            pnlOperation.Controls.Add(txtAmount);

            lblToAccountLbl = CreateStyledLabel("To Account:", null, Color.LightGray, new Point(20, 140));
            pnlOperation.Controls.Add(lblToAccountLbl);

            cmbToAccount = CreateStyledComboBox(new Point(150, 137));
            pnlOperation.Controls.Add(cmbToAccount);

            btnExecute = new Button
            {
                Text      = "CONFIRM",
                Size      = new Size(180, 42),
                Location  = new Point(150, 188),
                BackColor = Color.FromArgb(0, 150, 80),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font      = new Font("Segoe UI", 11f, FontStyle.Bold),
                Cursor    = Cursors.Hand
            };
            btnExecute.FlatAppearance.BorderSize = 0;
            btnExecute.Click += BtnExecute_Click;
            pnlOperation.Controls.Add(btnExecute);

            lblOpResult = new Label
            {
                AutoSize  = false,
                Size      = new Size(470, 26),
                Location  = new Point(20, 244),
                ForeColor = Color.LightGreen,
                Font      = new Font("Segoe UI", 10f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft
            };
            pnlOperation.Controls.Add(lblOpResult);
        }

        // ----------------------------------------------------------------
        // Operation panel mode switcher
        // ----------------------------------------------------------------

        /// <summary>
        /// Reconfigures the operation panel for the requested mode,
        /// showing and hiding controls as appropriate.
        /// </summary>
        private void ShowOperationPanel(OperationMode mode)
        {
            _currentMode = mode;
            ResetOperationPanel();

            switch (mode)
            {
                case OperationMode.Balance:
                    ShowBalanceMode();
                    break;

                case OperationMode.Deposit:
                    lblOpTitle.Text = "Deposit Funds";
                    ShowAccountAndAmountControls();
                    break;

                case OperationMode.Withdraw:
                    lblOpTitle.Text = "Withdraw Cash";
                    ShowAccountAndAmountControls();
                    break;

                case OperationMode.Transfer:
                    lblOpTitle.Text = "Transfer Money";
                    ShowAccountAndAmountControls();
                    ShowTransferDestinationControls();
                    break;

                case OperationMode.History:
                    ShowHistoryMode();
                    break;
            }
        }

        private void ResetOperationPanel()
        {
            lblOpResult.Text      = string.Empty;
            lblOpResult.ForeColor = Color.LightGreen;
            lblOpResult.Location  = new Point(20, 244);
            lblOpResult.Size      = new Size(470, 26);
            txtAmount.Text        = string.Empty;

            cmbAccount.Items.Clear();
            cmbToAccount.Items.Clear();

            cmbAccount.Visible      = false;
            lblAccountLabel.Visible = false;
            txtAmount.Visible       = false;
            lblAmountLabel.Visible  = false;
            cmbToAccount.Visible    = false;
            lblToAccountLbl.Visible = false;
            btnExecute.Visible      = false;
        }

        private void ShowBalanceMode()
        {
            lblOpTitle.Text      = "Account Balances";
            lblOpResult.Text     = $"Checking:  {_customer.Checking?.Balance:C}\n" +
                                   $"Savings:   {_customer.Savings?.Balance:C}";
            lblOpResult.Location = new Point(20, 60);
            lblOpResult.Size     = new Size(470, 60);
        }

        private void ShowAccountAndAmountControls()
        {
            cmbAccount.Items.Add("Checking");
            cmbAccount.Items.Add("Savings");
            cmbAccount.SelectedIndex = 0;
            cmbAccount.Visible       = true;
            lblAccountLabel.Visible  = true;
            txtAmount.Visible        = true;
            lblAmountLabel.Visible   = true;
            btnExecute.Text          = "CONFIRM";
            btnExecute.Visible       = true;
        }

        private void ShowTransferDestinationControls()
        {
            cmbToAccount.Items.Add("Checking");
            cmbToAccount.Items.Add("Savings");
            cmbToAccount.SelectedIndex = 1;
            cmbToAccount.Visible       = true;
            lblToAccountLbl.Visible    = true;
        }

        private void ShowHistoryMode()
        {
            lblOpTitle.Text = "Transaction History";
            cmbAccount.Items.Add("Checking");
            cmbAccount.Items.Add("Savings");
            cmbAccount.SelectedIndex = 0;
            cmbAccount.Visible       = true;
            lblAccountLabel.Visible  = true;
            btnExecute.Text          = "LOAD HISTORY";
            btnExecute.Visible       = true;
            lblOpResult.Size         = new Size(470, 120);
        }

        // ----------------------------------------------------------------
        // Confirm button handler
        // ----------------------------------------------------------------

        /// <summary>
        /// Dispatches to the appropriate operation based on <see cref="_currentMode"/>.
        /// Validates amount input before delegating to a specific handler.
        /// </summary>
        private void BtnExecute_Click(object? sender, EventArgs e)
        {
            lblOpResult.ForeColor = Color.LightGreen;
            lblOpResult.Text      = string.Empty;

            if (_currentMode == OperationMode.History)
            {
                ShowTransactionHistory();
                return;
            }

            if (!decimal.TryParse(txtAmount.Text.Trim(), out decimal amount) || amount <= 0)
            {
                ShowErrorMessage("Please enter a valid positive amount.");
                return;
            }

            Account? fromAccount = GetSelectedAccount(cmbAccount);
            if (fromAccount == null) return;

            switch (_currentMode)
            {
                case OperationMode.Deposit:
                    ExecuteDeposit(fromAccount, amount);
                    break;

                case OperationMode.Withdraw:
                    ExecuteWithdraw(fromAccount, amount);
                    break;

                case OperationMode.Transfer:
                    ExecuteTransfer(fromAccount, amount);
                    break;
            }
        }

        // ----------------------------------------------------------------
        // Core banking operations (polymorphic — work with Account objects)
        // ----------------------------------------------------------------

        /// <summary>Deposits <paramref name="amount"/> into <paramref name="account"/>.</summary>
        private void ExecuteDeposit(Account account, decimal amount)
        {
            account.Deposit(amount);
            SQLHelper.UpdateAccountBalance(account);
            SQLHelper.LogTransaction(account, "Deposit", amount);
            RefreshBalanceCards();
            lblOpResult.Text =
                $"✅  Deposited {amount:C} to {account.AccountType}. " +
                $"New balance: {account.Balance:C}";
        }

        /// <summary>
        /// Attempts to withdraw <paramref name="amount"/> from <paramref name="account"/>.
        /// Displays an error if funds are insufficient.
        /// </summary>
        private void ExecuteWithdraw(Account account, decimal amount)
        {
            // Polymorphism: CheckingAccount.Withdraw may pull from savings overdraft.
            bool success = account.Withdraw(amount);

            if (!success)
            {
                ShowErrorMessage(
                    $"Insufficient funds. {account.AccountType} balance: {account.Balance:C}");
                return;
            }

            // Both accounts may have changed if overdraft was used.
            SQLHelper.SaveCustomerAccounts(_customer);
            SQLHelper.LogTransaction(account, "Withdraw", amount);
            RefreshBalanceCards();
            lblOpResult.Text =
                $"✅  Withdrew {amount:C} from {account.AccountType}. " +
                $"New balance: {account.Balance:C}";
        }

        /// <summary>
        /// Transfers <paramref name="amount"/> from the selected source account
        /// to the selected destination account.
        /// </summary>
        private void ExecuteTransfer(Account fromAccount, decimal amount)
        {
            string sourceType      = cmbAccount.SelectedItem?.ToString()   ?? "Checking";
            string destinationType = cmbToAccount.SelectedItem?.ToString() ?? "Savings";

            if (sourceType == destinationType)
            {
                ShowErrorMessage("Cannot transfer to the same account.");
                return;
            }

            Account? toAccount = GetSelectedAccount(cmbToAccount);
            if (toAccount == null) return;

            bool success = fromAccount.Withdraw(amount);

            if (!success)
            {
                ShowErrorMessage(
                    $"Insufficient funds in {fromAccount.AccountType}. " +
                    $"Balance: {fromAccount.Balance:C}");
                return;
            }

            toAccount.Deposit(amount);
            SQLHelper.SaveCustomerAccounts(_customer);
            SQLHelper.LogTransaction(fromAccount, "Transfer-Out", amount);
            SQLHelper.LogTransaction(toAccount,   "Transfer-In",  amount);
            RefreshBalanceCards();
            lblOpResult.Text =
                $"✅  Transferred {amount:C} from " +
                $"{fromAccount.AccountType} to {toAccount.AccountType}.";
        }

        /// <summary>
        /// Loads and displays recent transaction history for the selected account.
        /// </summary>
        private void ShowTransactionHistory()
        {
            Account? account = GetSelectedAccount(cmbAccount);
            if (account == null) return;

            var historyRows = SQLHelper.GetTransactionHistory(account, maxRows: 8);

            if (historyRows.Count == 0)
            {
                lblOpResult.Text = "No transactions recorded yet.";
                return;
            }

            lblOpResult.Text      = string.Join("\n", historyRows);
            lblOpResult.ForeColor = Color.LightCyan;
            lblOpResult.Size      = new Size(470, historyRows.Count * 22 + 10);
        }

        // ----------------------------------------------------------------
        // Helpers
        // ----------------------------------------------------------------

        /// <summary>
        /// Returns the <see cref="Account"/> object corresponding to the
        /// selection in <paramref name="comboBox"/>.
        /// Returns <c>null</c> if the selected account does not exist for
        /// this customer.
        /// </summary>
        private Account? GetSelectedAccount(ComboBox comboBox)
        {
            string selection = comboBox.SelectedItem?.ToString() ?? "Checking";

            return selection == "Checking"
                ? (Account?)_customer.Checking
                : _customer.Savings;
        }

        /// <summary>Updates the checking and savings balance card labels.</summary>
        private void RefreshBalanceCards()
        {
            lblCheckingBal.Text = _customer.Checking?.Balance.ToString("C") ?? "N/A";
            lblSavingsBal.Text  = _customer.Savings?.Balance.ToString("C")  ?? "N/A";
        }

        /// <summary>Displays an error message in the result label.</summary>
        private void ShowErrorMessage(string message)
        {
            lblOpResult.ForeColor = Color.Tomato;
            lblOpResult.Text      = $"⚠  {message}";
        }

        /// <summary>Stops the clock, reopens the login form, and closes this form.</summary>
        private void Logout()
        {
            tmrClock.Stop();
            var loginForm = new LoginForm();
            loginForm.Show();
            Close();
        }

        // ----------------------------------------------------------------
        // UI factory helpers
        // ----------------------------------------------------------------

        /// <summary>
        /// Creates a consistently styled balance card panel with a title
        /// label and a large balance label.
        /// </summary>
        private Panel CreateBalanceCardPanel(Point location, Color accentColor)
        {
            var panel = new Panel
            {
                Size      = new Size(308, 76),
                Location  = location,
                BackColor = Color.FromArgb(45, 45, 65)
            };
            panel.Paint += (s, e) =>
            {
                using var pen = new Pen(accentColor, 2);
                e.Graphics.DrawRoundRect(
                    pen, new Rectangle(1, 1, panel.Width - 3, panel.Height - 3), 10);
            };

            var titleLabel = new Label
            {
                AutoSize  = false,
                Size      = new Size(268, 22),
                Location  = new Point(20, 10),
                ForeColor = Color.LightGray,
                Font      = new Font("Segoe UI", 10f)
            };
            var balanceLabel = new Label
            {
                AutoSize  = false,
                Size      = new Size(268, 32),
                Location  = new Point(20, 34),
                ForeColor = accentColor,
                Font      = new Font("Segoe UI", 18f, FontStyle.Bold)
            };

            panel.Controls.Add(titleLabel);
            panel.Controls.Add(balanceLabel);
            return panel;
        }

        /// <summary>Creates a consistently styled sidebar action button.</summary>
        private static Button CreateActionButton(string text, Point location)
        {
            var button = new Button
            {
                Text      = text,
                Size      = new Size(135, 42),
                Location  = location,
                BackColor = Color.FromArgb(55, 55, 80),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor    = Cursors.Hand,
                Font      = new Font("Segoe UI", 9.5f)
            };
            button.FlatAppearance.BorderColor = Color.FromArgb(80, 200, 255);
            button.FlatAppearance.BorderSize  = 1;
            return button;
        }

        /// <summary>Creates a consistently styled combo box for account selection.</summary>
        private static ComboBox CreateStyledComboBox(Point location)
        {
            return new ComboBox
            {
                Size          = new Size(220, 26),
                Location      = location,
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor     = Color.FromArgb(60, 60, 80),
                ForeColor     = Color.White,
                FlatStyle     = FlatStyle.Flat
            };
        }

        /// <summary>Creates a consistently styled label for the operation panel.</summary>
        private static Label CreateStyledLabel(
            string text, Font? font, Color foreColor, Point location)
        {
            return new Label
            {
                Text      = text,
                Font      = font ?? new Font("Segoe UI", 10f),
                ForeColor = foreColor,
                AutoSize  = true,
                Location  = location
            };
        }
    }
}
